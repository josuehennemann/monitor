# GoSNMP authors

* Jon Auer (@jda)
* Chris Dance (@codedance)
* Jacob Dubinsky (@jdubinsky)
* Eduardo Ferro (@eferro)
* Mattias Folke (@msfe)
* Geoff Garside (@geoffgarside)
* Miroslav Genov (@mgenov)
* Jaime Gil de Sagredo Luna (@jaimegildesagredo)
* Sonia Hamilton (@soniah)
* Marcin Jurczuk (@mrspock)
* Andreas Louca (@alouca)
* Nathan Owens (@virtuallynathan)
* Whitham Reeve (@wdreeveii)
* Benjamin Thomas (@benjamin-thomas)
* Ross Wilson (@schotlandzegtja)

In alphabetical order of surname. In vim: highlight, then `!sort -k3`.
